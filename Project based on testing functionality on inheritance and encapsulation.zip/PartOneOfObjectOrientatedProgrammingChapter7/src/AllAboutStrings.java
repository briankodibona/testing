public class AllAboutStrings {
    public static void main(String[] args) {
        printInformation("John is old");
        printInformation("");
        printInformation("    ");
        String helloWorld = "Hello World";
        System.out.printf("Index of r = %d %n", helloWorld.indexOf('r'));
        System.out.printf("Index of world = %d %n", helloWorld.indexOf("World"));
        System.out.printf("Index of L = %d %n", helloWorld.indexOf('l'));
        System.out.printf("Index of L = %d %n", helloWorld.lastIndexOf('l'));
        System.out.printf("Index of L = %d %n", helloWorld.indexOf('l',3));
        System.out.printf("Index of L = %d %n", helloWorld.lastIndexOf('l',8));

        String hellowWorldLower = helloWorld.toLowerCase();
        if (helloWorld.equals(hellowWorldLower)){
            System.out.println("Values match exactly");
        }

        if (helloWorld.equalsIgnoreCase(hellowWorldLower)) {
            System.out.println("Values match ignoring case");
        }
            if (helloWorld.startsWith("Hello")){
                System.out.println("Starts with hello");
            }
            if (helloWorld.endsWith("World")){
                System.out.println("Ends with World");
            }

            if (helloWorld.contains("World")){
                System.out.println("Contains World");
            }

            if (helloWorld.contentEquals("Hello World")){
                System.out.println("Vlues matches exactly");
            }

    }

    public static void printInformation(String string){
        int length = string.length();
        System.out.printf("Length = %d %n", length);
        if (string.isEmpty()){
            System.out.println("String is empty");
            return;
        }

        if(string.isBlank()){
            System.out.println("String is blank");
            return;
        }
        System.out.printf("First char = %c %n", string.charAt(0));

        System.out.printf("Last char = %c %n", string.charAt(length -1));

    }
}
