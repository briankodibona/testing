public class ObjectClass extends Object {

    public static void main(String[] args) {
        Student2 John = new Student2("John", 21);
        System.out.println(John);

        PrimarySchoolStudent Jimmy = new PrimarySchoolStudent("Jimmy", 8, "Carole");
        System.out.println(Jimmy);
    }
}

class Student2 {
    private String name;
    private int age;

    Student2(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
//        return "Student2{" +
//                "name='" + name + '\'' +
//                ", age=" + age +
//                '}';
        return name + " is " + age;
    }
   /* public toString(){
        return super.toString();
    }*/
}

    class PrimarySchoolStudent  extends Student2{
        private String parentName;

        PrimarySchoolStudent(String name, int age, String parentName){
            super(name, age);
            this.parentName = parentName;
        }

        @Override
        public String toString() {
            return parentName + "'s kid, " + super.toString();
        }
    }
