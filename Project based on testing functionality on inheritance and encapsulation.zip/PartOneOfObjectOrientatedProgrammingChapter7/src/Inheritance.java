public class Inheritance {
    public static void main(String[] args) {
        Car car = new Car();
        car.setMake("Porsche");
        car.setModel("Camera");
        car.setDoors(2);
        car.setColor("Red");
        car.setConvertible(false);
        System.out.println("make = " + car.getMake());
        System.out.println("model = " + car.getModel());
        car.describeCar();


        Car targa = new Car();
        car.setMake("Holden");
        car.setModel("Targa");
        car.setDoors(4);
        car.setColor("blue");
        car.setConvertible(true);
        System.out.println("make = " + car.getMake());
        System.out.println("model = " + car.getModel());
        targa.describeCar();
    }
}
