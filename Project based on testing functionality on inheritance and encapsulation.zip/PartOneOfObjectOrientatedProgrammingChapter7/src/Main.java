public class Main {
    public static void main(String[] args) {
        Customer customerNoConstructor = new Customer();
        Customer customerWithTwoConstructor = new Customer("Sarah", "Sarah@Email.com");
        Customer customerWithAllConstructors = new Customer("Peter", 100_000, "Peter@Email.com");

        System.out.println("Name: " + customerNoConstructor.getName()
                + " Withdraw limit: " + customerNoConstructor.getCreditLimit()
                + " Email: " + customerNoConstructor.getEmail());

        System.out.println("Name: " + customerWithAllConstructors.getName()
                + " Withdraw limit: " + customerWithAllConstructors.getCreditLimit()
                + " Email: " + customerWithAllConstructors.getEmail());

        System.out.println("Name: " + customerWithTwoConstructor.getName()
                + " Withdraw limit: " + customerWithTwoConstructor.getCreditLimit()
                + " Email: " + customerWithTwoConstructor.getEmail());


    }
}
